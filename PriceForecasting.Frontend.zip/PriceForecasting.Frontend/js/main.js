function goToMain() {
    window.location.href = '../html/main.html';
}